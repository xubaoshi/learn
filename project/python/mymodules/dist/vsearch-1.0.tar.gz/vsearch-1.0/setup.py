from setuptools import setup
setup(
    name='vsearch',
    version='1.0',
    description='The Python Tools',
    author='',
    py_modules=['vsearch'],
)
